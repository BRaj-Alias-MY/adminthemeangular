var useref = require('gulp-useref');
var minifyCss = require('gulp-minify-css');
var gulpif = require('gulp-if');
gulp.task('css-files', function () {
    var stream = gulp.src('./app/index.html')
        .pipe(useref()) //take a streem from index.html comment
        .pipe(gulpif('*.css', minifyCss())) // if .css file, minify
        .pipe(gulpif('*.css', gulp.dest('./dist'))) // copy to dist
        .pipe(gulpif('*.css', gulp.dest('./assets/bower_components/bootstrap'))); // copy to dist
    return stream;
});
